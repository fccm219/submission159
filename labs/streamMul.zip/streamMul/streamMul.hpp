#ifndef __STREAMMUL_HPP
#define __STREAMMUL_HPP

#include "ap_int.h"

//Add code here

void smul(axis_t *INPUT, axis_t *OUTPUT, unsigned int length);

#endif
