#include "streamMul.hpp"

void smul(axis_t *INPUT, axis_t *OUTPUT, unsigned int length){
//#pragma HLS INTERFACE s_axilite port=return bundle=CTRL
//#pragma HLS INTERFACE s_axilite port=length bundle=CTRL
//#pragma HLS INTERFACE axis depth=50 port=OUTPUT
//#pragma HLS INTERFACE axis depth=50 port=INPUT

	for(unsigned int i=0; i<length; i++){
		axis_t cur = *INPUT++;
		cur.data = cur.data * 2;
		*OUTPUT++ = cur;
	}
}
