#ifndef __STREAMADD_HPP
#define __STREAMADD_HPP

#include "ap_int.h"

struct axis_t {
	int data;
	ap_int<1> last;
};

void sadd(axis_t *INPUT1, axis_t *INPUT2, axis_t *OUTPUT, unsigned int length);

#endif
