#include "streamAdd.hpp"

void sadd(axis_t *INPUT1, axis_t *INPUT2, axis_t *OUTPUT, unsigned int length){
//#pragma HLS INTERFACE s_axilite port=return bundle=CTRL
#pragma HLS INTERFACE s_axilite port=length bundle=CTRL
#pragma HLS INTERFACE axis depth=50 port=OUTPUT
#pragma HLS INTERFACE axis depth=50 port=INPUT1
#pragma HLS INTERFACE axis depth=50 port=INPUT2

	for(unsigned int i=0; i<length; i++){
		axis_t cur1 = *INPUT1++;
		axis_t cur2 = *INPUT2++;
		cur1.data = cur1.data + cur2.data;
		*OUTPUT++ = cur1;
	}
}
